# Social_Media_Application
Java Project

This project is built around the idea of a social media application which is a java-based
project allowing people to communicate, share ideas, activities and events within the
network. This system focuses on online communication along with a security feature

## Screenshots/Output
![myimage-alt-tag](https://raw.githubusercontent.com/Bhavyav99/Social_Media_Application/master/Screenshots/Screenshot%20(234).png)

![myimage-alt-tag](https://raw.githubusercontent.com/Bhavyav99/Social_Media_Application/master/Screenshots/Screenshot%20(236).png)

![myimage-alt-tag](https://raw.githubusercontent.com/Bhavyav99/Social_Media_Application/master/Screenshots/Screenshot%20(238).png)

![myimage-alt-tag](https://raw.githubusercontent.com/Bhavyav99/Social_Media_Application/master/Screenshots/Screenshot%20(242).png)

![myimage-alt-tag](https://raw.githubusercontent.com/Bhavyav99/Social_Media_Application/master/Screenshots/Screenshot%20(244).png)
